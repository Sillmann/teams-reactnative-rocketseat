import { Groups } from './src/screens/Groups';

export default function App() {
  return (
    <Groups />
  );
}
